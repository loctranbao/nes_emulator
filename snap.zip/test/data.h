#pragma once
/*
* Copyright (C) 2019-2020, LG Electronics, All Right Reserved.
*
* This file is subject to the terms and conditions of
* Category B-B defined in the AASP Software License Agreement
* SPDX-License-Identifier: LicenseRef-LGE-Proprietary-Category-B-B
*/

/*! \file DTCMgt.h
 *
 *	@brief interface for DTCMgt.h.
 *
 ******************************************************************************/

#pragma once


// #include "CommonType.h"
// #include "Queue.h"
// #include "Singleton.h"
// #include "MsgDispatcher.h"
// #include "DID.h"
// #include "dcm_type.h"
// #include "IDiagHW.h"
// #include <android-base/properties.h>
// #include "DTCCallback.h"
// #include <vucs/core/VucServerApi.h>
// #include <vucs/core/DiagnosticManagerApi.h>

// #include <cutils/properties.h>

// #include <android/hardware/automotive/vehicle/2.0/IVehicle.h>
// #include <vendor/alliance/hardware/automotive/vehicle/2.0/types.h>
// #include <vendor/alliance/hardware/automotive/diagnosis/2.0/IDTCCallback.h>
// #include <vendor/alliance/hardware/automotive/diagnosis/2.0/IDTCResultCallback.h>

// using namespace android::hardware::automotive::vehicle::V2_0;
// using namespace vendor::alliance::hardware::automotive::vehicle::V2_0;
// using VehicleStatusCode = android::hardware::automotive::vehicle::V2_0::StatusCode;

// using ::android::hardware::Return;
// using ::android::hardware::Void;
// using ::android::hardware::hidl_vec;
// using ::android::sp;
// using ::android::hardware::automotive::vehicle::V2_0::IVehicle;
// using ::vendor::alliance::hardware::automotive::vehicle::V2_0::AllianceVehicleProperty;
// using ::android::hardware::automotive::vehicle::V2_0::VehicleProperty;

// using ::vucs::core::VucServerApi;
// using ::vucs::core::DiagnosticManagerApi;
// using ::vucs::core::DiagnosticManagerCallback;
// using ::vucs::core::VucsBuffer;
// using ::vucs::core::ReadDTCFlag;
// using VucServerStatusCode = ::vucs::core::StatusCode;

// using ::vendor::alliance::hardware::automotive::diagnosis::V2_0::DTCData;
// using ::vendor::alliance::hardware::automotive::diagnosis::V2_0::DTCCallbackData;
// using ::vendor::alliance::hardware::automotive::diagnosis::V2_0::IDTCCallback;
// using ::vendor::alliance::hardware::automotive::diagnosis::V2_0::IDTCResultCallback;

//TODO
//DIAG_DTC_VER_PI2.3 should be Modified after PI2.3.
#define DIAG_DTC_VER_PI23

// typedef uint8_t                         DTCFormatIdentifier;
#define ISO15031_6DTCFormat             ((DTCFormatIdentifier)0x00)
#define ISO14229_1DTCFormat             ((DTCFormatIdentifier)0x01)
#define SAEJ1939_73DTCFormat            ((DTCFormatIdentifier)0x02)
#define ISO11992_4DTCFormat             ((DTCFormatIdentifier)0x03)

// typedef uint8_t                         EventStatusType;
#define EVENT_STATUS_PASSED             ((EventStatusType)0x00)
#define EVENT_STATUS_FAILED             ((EventStatusType)0x01)

#define CHECK_FDC_PASSED                (uint8_t)-128
#define CHECK_FDC_FAILED                (uint8_t)127

#define UNVALIDINDEX                    -1

#define DTC_HIGH_BYTE(dtc)              (uint8_t)((dtc >> 16u) & 0xFFu)
#define DTC_MID_BYTE(dtc)               (uint8_t)((dtc >> 8u) & 0xFFu)
#define DTC_LOW_BYTE(dtc)               (uint8_t)(dtc & 0xFFu)
#define DTC_CODE(dtc)                   (((uint16_t)DTC_HIGH_BYTE(dtc) << 8u) | DTC_MID_BYTE(dtc))
#define DTC_FAULT_TYPE(dtc)             (DTC_LOW_BYTE(dtc))

#define DTC_DATA_READ_COUNT             1

enum Snapshot_Record {
    SNAPSHOT_RECORD_NUM_1 = 0x01,
    SNAPSHOT_RECORD_NUM_2 = 0x02,
    SNAPSHOT_RECORD_NUM_3 = 0x03,
    SNAPSHOT_RECORD_NUM_4 = 0x04,
    SNAPSHOT_RECORD_MAX_NUM = 0XFF
};

#define NUM_OF_SNAPSHOTS_RECORD         0x03

#define SNAPSHOT_RECORD_NUM_OF_IDENTIFIERS_REC_NUM1    0x04
#define SNAPSHOT_RECORD_NUM_OF_IDENTIFIERS_REC_NUM2    0x04
#define SNAPSHOT_RECORD_NUM_OF_IDENTIFIERS_REC_NUM3    0x08
#define SNAPSHOT_RECORD_NUM_OF_IDENTIFIERS_REC_NUM4    0x01

#define TEST_ALL_OPTION_CODE            0xFFFFu
#define PRESENT_CONFIG_VALUE            0u
#define ABSENT_CONFIG_VALUE             1u

#define MICRO_SEC                       1
#define MILLI_SEC                       (MICRO_SEC * 1000)
#define SEC                             (MILLI_SEC * 1000)

#define NUM_OF_DTC_CONFIG               25
#define NUM_OF_SELFDIAG                 18
#define NUM_OF_ASSETS_DTC               3
#define NUM_OF_HU_INTER_FAILURE_2       1
#define NUM_OF_EEARCHITECTURE_DTC       1
#define NUM_OF_DTC                      DTC_FD00_51 //153
#define NUM_OF_START_CAL_DTC            DTC_FD00_51
#define CONVERT_TO_CAL_INDEX(idx)       (NUM_OF_START_CAL_DTC+(idx*3))
#define NUM_OF_DTC_MUX                  45
#define SIZE_OF_DTC_CALIBRATION         120
#define NUM_OF_INTERFDTC                16

#define SIZE_CASSETS_PKG_FAILED         32 //byte
#define SIZE_CASSETS_DEPEND_FAILED      64 //byte
#define SIZE_CASSETS_RES_FAILED         80 //byte

#define SIZE_SS_RECORD_NUM_03_LABEL     62 //byte

#define PASS                            0x00u
#define FAIL                            0x01u

#define DTC_ALL_CLEAR                   (0x00FFFFFF)

typedef uint8_t                         StatusDTCType;
#define STATUS_INITIAL_VALUE            (StatusDTCType)0x10u
#define STATUS_PASS_VALUE               (StatusDTCType)0x00u
#define STATUS_HISTORICAL_VALUE         (StatusDTCType)0x28u
#define STATUS_FAIL_VALUE               (StatusDTCType)0x29u

#define CHK_TESTFAILED_BIT              0x01u

#define READ_MAX_NODE_LENGTH            20

#define MAX_STRING_LENGTH               256u
#define GET_PRODUCT_PATH                "ro.product.device"
#define AIVI2_FULL                      "aivi2_full"
#define AIVI2_N_FULL                    "aivi2_n_full"
#define AIVI2_CORE                      "aivi2_core"
#define GET_FACTORY_MODE                "ro.boot.factorymode"
#define GET_BOOT_REASON_LG              "ro.boot.product.lge.bootreasoncode"
#define GET_BOOT_REASON_VENDOR          "vendor.alliance.boot.reason"
#define FACTORYMODE_PROPERTY            "1"
#define INTERCONNECT_WATCHDOG           "interconnect_watchdog"
#define INTERCONNECT_FORCEOFF           "interconnect_forceoff"
#define VUC_ERRORHOOK                   "vuc_errorhook"
#define VUC_WATCHDOG                    "vuc_watchdog"
// BSP Node Path
#define ANTENNA_FULL_PATH               "sys/bus/iio/devices/iio:device1/in_voltage_wifi_dtc_in_input"
#define ANTENNA_CORE_PATH               "sys/bus/iio/devices/iio:device0/in_voltage_wifi_dtc_in_input"
#define PANEL_PATH                      "sys/class/panel/serdes/linefault"
#define TOUCH_PATH                      "sys/class/lge_touch/synaptics_dsx/manufacture_id"
#define CVBS_REAR_CAMERA_PATH           "sys/class/camera_dtc/dtc/analog_rvc_lock_status"
#define LVDS_CAMERA_PATH                "sys/class/camera_dtc/dtc/avm_lock_status"
#define LVDS_FRONT_CAMERA_PATH          "sys/class/camera_dtc/dtc/ar_cam_lock_status"
#define ECU_CPU_PATH                    "sys/devices/system/cpu/cpu%d/online"
#define ECU_LPDDR4_PATH                 "proc/meminfo"
#define ECU_EMMC_FULL_PATH              "sys/kernel/debug/1d84000.ufshc/err_state"
#define ECU_EMMC_CORE_PATH              "sys/kernel/debug/mmc0/err_state"
#define ECU_PMIC_MASTER_PATH            "sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-00/uevent"
#define ECU_PMIC_SLAVE_PATH             "sys/devices/platform/soc/c440000.qcom,spmi/spmi-0/spmi0-04/uevent"
#define ECU_SERIALIZER_PATH             "sys/class/panel/serdes/serializer"
#define ECU_DESERIALIZER_PATH           "sys/class/camera_dtc/dtc/avm_desid"
#define ECU_RVC_CVBS_PATH               "sys/class/camera_dtc/dtc/analog_rvc_ident"
#define OL_MCH1_USB_PATH                "sys/devices/platform/soc/a600000.ssusb/usb_openload"
#define CF_MCH1_USB_PATH                "sys/devices/platform/soc/a600000.ssusb/usb_invalid"
#define OL_TCU_USB_PATH                 "sys/devices/platform/soc/a800000.%s/usb_openload"
#define CF_TCU_USB_PATH                 "sys/devices/platform/soc/a800000.%s/usb_error"
#define AIO_LOCK_CAMERA_PATH            "sys/class/camera_dtc/dtc/aio_cam_lock_status"
#define AIO_FAILURE_CAMERA_PATH         "sys/class/camera_dtc/dtc/aio_cam_hw_fault_status"

// BSP Node Result
#define DTC_BSP_RESULT_MAXLENGTH        2u
#define DTC_BSP_RESULT_OK               "0"
#define DTC_BSP_RESULT_NOK              "1"
#define BSP_RESULT_OK                   "1"
#define BSP_RESULT_NOK                  "0"
#define DTC_BSP_RESULT_LENGTH           strnlen(DTC_BSP_RESULT_NOK, DTC_BSP_RESULT_MAXLENGTH)
#define BSP_ETHERNET_SWITCH_OK          "Erika-avb_switch Ver"
#define WIFI_ANTENNA_OPENLOAD           1500000
#define WIFI_ANTENNA_SHORT_TO_GROUND    1050000

#define DID_CODE_SIZE                   2
#define DID_DATA_BATTERYLEVEL_SIZE      1



#define SNAPSHOT_DID_MILEAGE                            0xF0D0u
#define SNAPSHOT_DID_OCNT                               0xF0D1u
#define SNAPSHOT_DID_SUPPLY_VOLT                        0x0131u
#define SNAPSHOT_DID_INTERNAL_TEMP                      0x0138u
#define SNAPSHOT_DID_CUSTOM_ASSETS_PACKAGE_FAILED       0x0133u
#define SNAPSHOT_DID_CUSTOM_ASSETS_DEPENDENCY_FAILED    0x0134u
#define SNAPSHOT_DID_CUSTOM_ASSETS_RESOURCE_FAILED      0x0135u
#define SNAPSHOT_DID_CNF_CUSTOM_ASSETS_ERROR_CODE       0x0136u
#define SNAPSHOT_DID_KERNEL_SOFTWARE_WATCHDOG           0x0140u
#define SNAPSHOT_DID_SOC_HW_NON_SECURE_WD               0x0141u
#define SNAPSHOT_DID_SOC_BUS_HANG                       0x0142u
#define SNAPSHOT_DID_SOC_HW_SECURE_WD                   0x0143u
#define SNAPSHOT_DID_UC_SOC_PING_VHAL_COMMUNICATION     0x0144u
#define SNAPSHOT_DID_VUC_SOC_GPIO_ON_SHUTDOWN_PHASE     0x0145u
#define SNAPSHOT_DID_ERRORHOOK_RESET                    0x0146u
#define SNAPSHOT_DID_WATCHDOG_RESET                     0x0147u
#define SNAPSHOT_DID_EEARCHITECTURE_INFO                0x0148u

#define SNAPSHOT3_REC_TIMES      10
#define SNAPSHOT3_TIME_SIZE      6

// Define DTC
#define DTC_MULTI_CAN_EXT_COMMUNICATION             0xD000u
#define DTC_MULTI_CAN_M_COMMUNICATION               0xD300u
#define DTC_IVI_CAN_COMMUNICATION                   0xEA13u
#define DTC_M1_CAN_COMMUNICATION                    0xEA10u
#define DTC_HU_INTER_SELF_DIAGNOSIS                 0x9341u
#define DTC_INTERNAL_SELF_DIAG                      0x93ECu
#define DTC_SOUND_BUBBLE_R                          0x930Eu
#define DTC_SOUND_BUBBLE_L                          0x9310u
#define DTC_LOUDSPK_R_SUBWOOFER                     0x9344u
#define DTC_LOUDSPK_L_SUBWOOFER                     0x9345u
#define DTC_LOUDSPK_FR                              0x930Du     // FRONT RIGHT
#define DTC_LOUDSPK_RL                              0x9311u      // REAR LEFT
#define DTC_LOUDSPK_FL                              0x930Fu      // FRONT LEFT
#define DTC_LOUDSPK_RR                              0x930Bu      // REAR RIGHT
#define DTC_LOUDSPK_R_SURROUND                      0x930Au
#define DTC_LOUDSPK_L_SURROUND                      0x930Cu
#define DTC_LOUDSPK_CENTERFILL                      0x9348u
#define DTC_LOUDSPK_RR_TWEETER                      0x9320u      // REAR RIGHT
#define DTC_LOUDSPK_FR_TWEETER                      0x9321u      // FRONT RIGHT
#define DTC_LOUDSPK_FL_TWEETER                      0x9322u      // FRONT LEFT
#define DTC_LOUDSPK_RL_TWEETER                      0x9323u      // REAR LEFT
#define DTC_ANTENNA_AM_FM1                          0x9315u
#define DTC_ANTENNA_FM2                             0x9316u
#define DTC_ANTENNA_SXM                             0x9317u
#define DTC_ANTENNA_GNSS                            0x9346u
#define DTC_ANTENNA_DAB                             0x9303u
#define DTC_ANTENNA_WIFI_EXT                        0x9314u
#define DTC_BAD_DISPLAY_SIGNAL                      0x9300u
#define DTC_MICROPHONE                              0x9327u
#define DTC_USB_MCH1                                0x932Au
#define DTC_USB_MCH1_ERRATIC                        0x93D9u
#define DTC_USB_TCU                                 0x932Cu
#define DTC_USB_TCU_ERRATIC                         0x93E5u
#define DTC_CENTRAL_GATEWAY_ETHERNET                0x931Au
#define DTC_AIO_CAMERA_ETHERNET                     0x931Bu
#define DTC_TCU_ETHERNET                            0x931Cu
#define DTC_ANALOG_RVC_VIDEO                        0x9339u
#define DTC_ANALOG_DIGIT_RVC_SUPPLY                 0x9375u
#define DTC_DIGIT_RVC_AVM_VIDEO                     0x93DAu
#define DTC_CENTRAL_PANEL                           0x93DDu
#define DTC_LVDS_2ND_DISPLAY                        0x93DBu
#define DTC_LVDS_DTV_BOX                            0x93D8u
#define DTC_LVDS_OUT_RSE                            0x93DFu
#define DTC_LVDS_IN_DVR_LINE                        0x9312u
#define DTC_AR_NAV_CAMERA                           0x931Du
#define DTC_HU_INTER_ECU_LOCKED                     0x9342u
#define DTC_HU_INTER_ECU_BUTTONS                    0x93CFu
#define DTC_HU_INTER_ECU_DCLASS_AMP_N1              0x9351u
#define DTC_HU_INTER_ECU_BT_WIFI                    0x9347u
#define DTC_HU_INTER_ECU_FAN                        0x935Eu
#define DTC_HU_INTER_ECU_GNSS                       0x931Eu
#define DTC_HU_INTER_ECU_DSP                        0x931Fu
#define DTC_HU_INTER_ECU_CPU                        0x9324u
#define DTC_HU_INTER_ECU_A2B                        0x9325u
#define DTC_HU_INTER_ECU_DCLASS_AMP_N2              0x9326u
#define DTC_HU_INTER_ECU_LPDDR4                     0x932Bu
#define DTC_HU_INTER_ECU_EMMC_UFS                   0x932Du
#define DTC_HU_INTER_ECU_PMIC                       0x932Eu
#define DTC_HU_INTER_ECU_ETHERNET_SWITCH            0x932Fu
#define DTC_HU_INTER_ECU_CP_SERIAL                  0x9330u
#define DTC_HU_INTER_ECU_AVM_RVC_DESERIAL           0x9331u
#define DTC_HU_INTER_ECU_RVC_CVBS                   0x9332u
#define DTC_HU_INTER_ECU_MICOM                      0x9334u
#define DTC_A2B                                     0x9335u
#define DTC_PART_AUTHENTICATION                     0x93E1u
#define DTC_FOTA                                    0xAE22u
#define DTC_AR_CAMERA                               0x9337u
#define DTC_HU_INTER_FAILURE_2                      0x9352u
#define DTC_EE_ARCHI_CONFIG                         0x9306u
#define DTC_C_ASSETS_REFERENCE_NF                   0x9357u
#define DTC_C_ASSETS_DEFENDENCY_INST_NF             0x9358u
#define DTC_ASSETSD_RUNTIME_ERROR                   0x9359u
#define DTC_SAFE_MODE                               0x93E0u
#define DTC_EHORIZON_LICENCE_ENROLLMENT             0x9307u

// DTC Mux
#define DTC_ACU_A101                                0XE150
#define DTC_ADAS_A116                               0XE152
#define DTC_ATCU_A109                               0XE141
#define DTC_AUDIOAMP_A1                             0XE025
#define DTC_AVM_A102                                0XE175
#define DTC_BCM_A107                                0XE14F
#define DTC_CDM_A116                                0XE176
#define DTC_CGW_A2                                  0XE18C
#define DTC_USM_A101                                0XE15B
#define DTC_DMC_A101                                0XE19D
#define DTC_DSMU_A101                               0XE193
#define DTC_ECM_A108                                0XE140
#define DTC_EPS_A103                                0XE159
#define DTC_FRCAMERA_A110                           0XE16B
#define DTC_FWS_R3                                  0XE104
#define DTC_HEVC_A104                               0XE143
#define DTC_HFM_A101                                0XE118
#define DTC_HUD_A1                                  0XE173
#define DTC_HVAC_A2                                 0XE1A0
#define DTC_METER_A103                              0XE14E
#define DTC_PSCU_A102                               0XE194
#define DTC_SONAR_A4                                0XE165
#define DTC_SRRR_A106                               0XE16E
#define DTC_SR_CANHS_R_02                           0XE187
#define DTC_TCU_A101                                0XE117
#define DTC_VDC_A114                                0XE148
#define DTC_VSP_A101                                0XE113
#define DTC_WCBS_A101                               0XE18D
#define DTC_STRG_A1                                 0XE156
#define DTC_CENTRALPANEL_R101                       0XE073
#define DTC_CPLC_R101                               0xE181
#define DTC_PBD_A102                                0xE169
#define DTC_FWD_A103                                0xE14A
#define DTC_PSD_A102                                0xE167
#define DTC_PSDL_A102                               0xE162
#define DTC_RSCU2R_A101                             0xE1B6
#define DTC_RSCU3R_A101                             0xE1BB
#define DTC_SCCM_A102                               0xE195
#define DTC_BLM_A101                                0xE1A3
#define DTC_AAM_R101                                0xE18E
#define DTC_AIRSUSP_N101                            0xE1BE
#define DTC_METER_R101                              0xE24E
#define DTC_FCP_N101                                0xE2B8
#define DTC_RCP_A101                                0xE2B9
#define DTC_EPS_A101                                0xE119

// define Fault Type
#define FT_GENERAL_ELECTRONIC_FAILURE               0x01u
#define FT_ALGORYTHM_BASED_FAILURE                  0x06u
#define FT_SHORT_TO_GROUND                          0x11u
#define FT_SHORT_TO_BATTERY                         0x12u
#define FT_OPEN_LOAD                                0x13u
#define FT_LOW_VOLTAGE_ERROR                        0x16u
#define FT_HIGH_VOLTAGE_ERROR                       0x17u
#define FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE             0x1Cu
#define FT_INVALID_SIGNAL                           0x29u
#define FT_GENERAL_MEMORY                           0x42u
#define FT_WATCHDOG_SAFETY_FAILURE                  0x47u
#define FT_INTERNAL_ELECTRONIC_FAILURE              0x49u
#define FT_NOT_PROGRAMMED                           0x51u
#define FT_NOT_ACTIVATED                            0x52u
#define FT_NOT_CONFIGURED                           0x55u
#define FT_INCOMPATIBLE_CONFIGURATION               0x56u
#define FT_SIGNAL_COMPARE_FAILURE                   0x62u
#define FT_ACTUATOR_STUCK_CLOSED                    0x73u
#define FT_MISSING_MESSAGE                          0x87u
#define FT_BUS_OFF                                  0x88u
#define FT_COMMUNICATION_FAILURE                    0x8Fu
#define FT_HIGH_TEMPERATURE                         0x98u
#define FT_ALGORITHM_FAILURE                        0x07u

#define INTER_TEMPERATURE_RESOLUTION                10
#define INVALID_VALUE                               0xFFu

#define BOOT_REASON_LENGTH                          20u
#define BOOT_REASON_MSM_WDOG_BARK                   "0x101"
#define BOOT_REASON_MSM_SECURE_WTD                  "0x103"
#define BOOT_REASON_APPS_WATCHDOG                   "0x6D630103"
#define BOOT_REASON_WDOG_BARK                       "0x6D63033a"
#define BOOT_REASON_NON_SECURE_WDT                  "0x6D630301"
#define BOOT_REASON_SECURE_WDT                      "0x6D630302"
#define BOOT_REASON_SECURE_WDT_TIMER                "0x6D630333"
#define BOOT_REASON_TZ_CRASH_AHB_TIMEOUT            "0x6D630303"
#define BOOT_REASON_TZ_CRASH_NOC_ERR                "0x6D630306"
#define BOOT_REASON_TZ_CRASH_XPU_VIOLATION          "0x6D630309"
#define BOOT_REASON_TZ_CRASH_SMMU_FAULT             "0x6D63030a"

#define BSP_CHECK_PERIOD_1S                         (1*2)
#define BSP_CHECK_PERIOD_5S                         (5*2)
#define BSP_CHECK_PERIOD_10S                        (10*2)
#define MAX_VALUE_CHECK_PERIOD                      65000

#define MAX_VALUE_OF_MILEAGE                        (0x000F423F)
#define MASK_CLEAR                                  0xEFu
#define CLEAR_FAULT                                 0xFEu

// Gade Define Value
#define SLEEP_OR_CRANK_FAULT                       0b000
#define AUTO_ACC_FAULT                             0b001
#define DISABLE_DIAGMUXDTC_ALL_FAULT               0b010
#define ENABLE_DIAGMUXDTC_ALL_FAULT                0b011
#define FOTA_SWITCH_FAULT                          0b100
#define GADE_LEVEL_5                               0b101
#define GADE_LEVEL_6                               0b110
#define UNAVAILABLE_GADE                           0b111

enum DISPLAY_TOUCH_SCREEN_CNF {
    NOT_CONFIGURED,
    WITH_DISPLAY_BOARD,
    CENTRAL_PANEL_9_INCHES,
    CENTRAL_PANEL_12_INCHES,
    LANDSCAPE_SCREEN_10_1_INCHES,
    PORTRAIT_SCREEN_10_4_INCHES,
    ATTACHED_DISPLAY,
    VISTEON_DISPLAY_PZ1A,
    VISTEON_DISPLAY_61QR,
    CLARION_DISPLAY_J32V,
    CONTINENTAL_DISPLAY_UZ2C,
    MELCO_DISPLAY_P33A,
    VISTEON_DISPLAY_P61R,
    VISTEON_10_1_INCHES,
    CUSTOM_DISPLAY
};

// enum DTC List Implemented via Interface
enum {
    PART_ACS_DTC_INDEX,                          // 0
    PART_ANTITHEFT_INDEX,                        // 1
    PART_ASSETD_REF_NF_INDEX,                    // 2
    PART_ASSETD_DEF_NF_INDEX,                    // 3
    PART_ASSETD_RUNTIME_ERR_INDEX,               // 4
    PART_BT_INDEX,                               // 5
    PART_FOTA_INDEX,                             // 6
    PART_INPUTMANAGER_INDEX,                     // 7
    PART_MSC_CGATEWAY_ETH_INDEX,                 // 8
    PART_MSC_AIOCAMERA_ETH_INDEX,                // 9
    PART_MSC_AIOCAMERA_ETH_MM_INDEX,             // 10
    PART_MSC_TCU_ETH_INDEX,                      // 11
    PART_MSC_ECU_ETH_SWITCH_INDEX,               // 12
    PART_NAVI_INDEX,                             // 13
    PART_WIFI_INDEX,                             // 14
    PART_TOUCH_DTC_INDEX,                        // 15
    PART_PANEL_DTC_INDEX,                        // 16
    PART_BAD_DISPLAY_SIGNAL_INDEX,               // 17
    PART_SAFE_MODE_INDEX                         // 18
};


/**
 * @brief list of all DTC that is supported
 * Note:
 *  when adding new DTC to the list
 *  if it is a calibration DTC -> add it to the end of the list before DTC_MAX
 *  if it is not a calibration DTC -> add it right above DTC_FD00_51
 */
enum {
    DTC_D000_88,             // General Electrical Failure(Ext-CAN Bus Off condition/Ext-CAN
    DTC_D300_88,             // General Electrical Failure(M-CAN Bus Off Condition/M-CAN
    DTC_9341_16,             // Low voltage error
    DTC_9341_17,             // High voltage error
    DTC_9341_98,             // H/U High temperature
    DTC_930E_11,
    DTC_930E_12,
    DTC_930E_13,
    DTC_930E_1C,
    DTC_9310_11,
    DTC_9310_12,
    DTC_9310_13,
    DTC_9310_1C,
    DTC_9344_11,
    DTC_9344_12,
    DTC_9344_13,
    DTC_9344_1C,
    DTC_9345_11,
    DTC_9345_12,
    DTC_9345_13,
    DTC_9345_1C,
    DTC_930D_11,
    DTC_930D_12,
    DTC_930D_13,
    DTC_930D_1C,
    DTC_9311_11,
    DTC_9311_12,
    DTC_9311_13,
    DTC_9311_1C,
    DTC_930F_11,
    DTC_930F_12,
    DTC_930F_13,
    DTC_930F_1C,
    DTC_930B_11,
    DTC_930B_12,
    DTC_930B_13,
    DTC_930B_1C,
    DTC_930A_11,
    DTC_930A_12,
    DTC_930A_13,
    DTC_930A_1C,
    DTC_930C_11,
    DTC_930C_12,
    DTC_930C_13,
    DTC_930C_1C,
    DTC_9348_11,
    DTC_9348_12,
    DTC_9348_13,
    DTC_9348_1C,
    DTC_9320_13,            // Open load
    DTC_9323_13,            // Open load
    DTC_9321_11,
    DTC_9321_12,
    DTC_9321_13,
    DTC_9321_1C,
    DTC_9322_11,
    DTC_9322_12,
    DTC_9322_13,
    DTC_9322_1C,
    DTC_9315_11,            // Circuit short to ground
    DTC_9315_13,            // Open load
    DTC_9316_11,            // Circuit short to ground
    DTC_9316_13,            // Open load
    DTC_9346_11,            // Circuit short to ground
    DTC_9346_13,            // Open load
    DTC_9303_11,            // Circuit short to ground
    DTC_9303_13,            // Open load
    DTC_9327_11,            // short circuit to ground
    DTC_9327_12,            // short circuit to battery
    DTC_9327_13,            // open load
    DTC_9375_11,            // Circuit short to ground
    DTC_9375_12,            // Open load
    DTC_9375_13,            // Circuit short to battery
    DTC_9351_49,            // ECU D-class Amplifier n1
    DTC_935E_49,            // ECU FAN
    DTC_931F_49,            // ECU DSP
    DTC_9325_49,            // ECU A2B tranceiver
    DTC_9326_49,            // ECU D-class Amplifier n2
    DTC_9335_8F,            // A2B
    DTC_E150_87,            // ACU_A101
    DTC_E152_87,            // ADAS_A116
    DTC_E141_87,            // ATCU_A109
    DTC_E025_87,            // AUDIOamp_A1
    DTC_E175_87,            // AVM_A102
    DTC_E14F_87,            // BCM_A107
    DTC_E176_87,            // CDM_A116
    DTC_E18C_87,            // CGW_A2
    DTC_E15B_87,            // USM_A101
    DTC_E19D_87,            // DMC_A101
    DTC_E193_87,            // DSMU_A101
    DTC_E140_87,            // ECM_A108
    DTC_E159_87,            // EPS_A103
    DTC_E16B_87,            // FRCAMERA_A110
    DTC_E104_87,            // FWS_A102
    DTC_E143_87,            // HEVC_A104
    DTC_E118_87,            // HFM_A101
    DTC_E173_87,            // HUD_A1
    DTC_E1A0_87,            // HVAC_A2
    DTC_E14E_87,            // METER_A103
    DTC_E194_87,            // PSCU_A102
    DTC_E165_87,            // SONAR_A4
    DTC_E16E_87,            // SRRR_A106
    DTC_E187_87,            // SR_CANHS_R_02
    DTC_E117_87,            // TCU_A101
    DTC_E148_87,            // VDC_A114
    DTC_E113_87,            // VSP_A101
    DTC_E18D_87,            // WCBS_A101
    DTC_E156_87,            // STRG_A1
    DTC_E073_87,            // CentralPanel_R101
    DTC_9341_49,            // H/U Internal Electronic Failure
    DTC_9341_55,            // Configuration error
    DTC_93EC_55,            // Configuration error2 (device in delivery condition)
    DTC_93EC_52,           // Factory mode
    DTC_9314_11,           // Short to GND
    DTC_9314_13,           // Open
    DTC_932A_13,           // Open load
    DTC_93D9_8F,           // communication failure
    DTC_932C_13,           // Open load
    DTC_93E5_8F,           // communication failure
    DTC_931A_8F,           // Central Gateway ethernet     Open load
    DTC_931B_8F,           // AIO camera ethernet          Open load
    DTC_931C_8F,           // TCU ethernet                 Open load
    DTC_9339_8F,           // CVBS IN rear cam line        Analog RVC video
    DTC_93DA_8F,           // Digital RVC or AVM video     LVDS In LVDS Camera
    DTC_93DD_8F,           // Central Panel                LVDS IN CP Line
    DTC_93DD_87,           // Touch
    DTC_93DB_8F,           // LVDS IN 2nd Display
    DTC_93DB_87,           // LVDS IN 2nd Display
    DTC_93D8_8F,           // LVDS IN DTV Box
    DTC_93DF_8F,           // LVDS OUT RSE
    DTC_931D_8F,           // AR NAV camera
    DTC_9342_62,           // Anthift(Locked ECU)
    DTC_93CF_73,           // ECU Buttons
    DTC_9347_49,           // ECU Bluetooth/Wifi module
    DTC_931E_49,           // ECU GNSS
    DTC_9324_49,           // ECU CPU
    DTC_932B_49,           // ECU LPDDR4
    DTC_932D_49,           // ECU eMMC/UFS
    DTC_932E_49,           // ECU PMIC
    DTC_932F_49,           // ECU Ethernet switch
    DTC_9330_49,           // ECU CP serializer
    DTC_9331_49,           // ECU AVM/RVC deserializer
    DTC_9332_49,           // ECU RVC CVBS
    DTC_93E1_06,           // Part Enrollment Error        Part Authentication   Algorithm Based Failures
    DTC_AE22_06,           // FOTA _Inconsistency_state    FOTA
    DTC_9337_11,           // AR NAV camera supply         Short to ground
    DTC_9337_12,           // AR NAV camera supply         Short to battery
    DTC_9337_13,           // AR NAV camera supply         Open load
    DTC_9352_47,           // HU Internal failure 2
    DTC_9357_29,           // CUSTOM_ASSETS_REFERENCE not found
    DTC_9358_29,           // CUSTOM_ASSETS_INSTALLED_X not found
    DTC_9359_06,           // ASSETD Runtime error         Algorythm based failure
    DTC_93E0_47,           // Safe Mode
    DTC_EA13_88,             // Bus OFF IVI-CAN
    DTC_EA10_88,             // Bus OFF M1-CAN
    DTC_9320_11,            // Short to ground
    DTC_9320_12,            // Short to battery
    DTC_9320_1C,            // Circuit Voltage Out of Range
    DTC_9323_11,            // Short to ground
    DTC_9323_12,            // Short to battery
    DTC_9323_1C,            // Circuit Voltage Out of Range
    DTC_9317_11,            // Circuit short to ground
    DTC_9317_13,            // Open load
    DTC_E181_87,            // CPLC_R101
    DTC_E169_87,            // PBD_A102
    DTC_E14A_87,            // FWD_A103
    DTC_E167_87,            // PSD_A102
    DTC_E162_87,            // PSDL_A102
    DTC_E1B6_87,            // RSCU2R_A101
    DTC_E1BB_87,            // RSCU3R_A101
    DTC_E195_87,            // SCCM_A102
    DTC_E1A3_87,            // BLM_A101
    DTC_E18E_87,            // AAM_R101
    DTC_E1BE_87,            // AirSUSP_N101
    DTC_E2B8_87,            // FCP_N101
    DTC_E2B9_87,            // RCP_A101
    DTC_E119_87,            // EPS_A101
    DTC_E24E_87,            // METER_R101
    DTC_9300_29,           // Bad display signal
    DTC_931B_49,
    DTC_9312_8F,           // LVDS in DVR Line
    DTC_9306_56,
    DTC_9307_07,           // EHorizon Enrollment license

    // Calibration Logical block
    // fault type   0x06:algorithm based failures
    // 0x42:Systeme internal failures/General memory failure
    // 0x51:Programming failure/Not programmed
    DTC_FD00_51,           // XTRADATA_F012
    DTC_FD00_06,
    DTC_FD00_42,
    DTC_FD01_51,           // ARKAMYS_SOUNDSTAGGING_CLASSIC_LHD
    DTC_FD01_06,
    DTC_FD01_42,
    DTC_FD02_51,           // ARKAMYS_SOUNDSTAGGING_CLASSIC_RHD
    DTC_FD02_06,
    DTC_FD02_42,
    DTC_FD03_51,           // ARKAMYS_SOUNDSTAGGING_AUDITO_LHD
    DTC_FD03_06,
    DTC_FD03_42,
    DTC_FD04_51,           // ARKAMYS_SOUNDSTAGGING_AUDITO_RHD
    DTC_FD04_06,
    DTC_FD04_42,
    DTC_FD05_51,           // ARKAMYS_SOUNDSTAGGING_FLAT
    DTC_FD05_06,
    DTC_FD05_42,
    DTC_FD06_51,           // ARKAMYS_3D_ADAS_LHD
    DTC_FD06_06,
    DTC_FD06_42,
    DTC_FD07_51,           // ARKAMYS_3D_ADAS_RHD
    DTC_FD07_06,
    DTC_FD07_42,
    DTC_FD08_51,           // ARKAMYS_3D_ADAS_FLAT
    DTC_FD08_06,
    DTC_FD08_42,
    DTC_FD09_51,           // ARKAMYS_SOUNDBUBBLE
    DTC_FD09_06,
    DTC_FD09_42,
    DTC_FD0A_51,           // ARKAMYS_SOUNDBUBBLE_FLAT
    DTC_FD0A_06,
    DTC_FD0A_42,
    DTC_FD0B_51,           // ECNR_BtVoiceNb_LHD
    DTC_FD0B_06,
    DTC_FD0B_42,
    DTC_FD0C_51,           // ECNR_BtVoiceWb
    DTC_FD0C_06,
    DTC_FD0C_42,
    DTC_FD0D_51,           // ECNR_Carplay_NBS_USB
    DTC_FD0D_06,
    DTC_FD0D_42,
    DTC_FD0E_51,           // ECNR_Carplay_WBS_USB
    DTC_FD0E_06,
    DTC_FD0E_42,
    DTC_FD0F_51,           // ECNR_Carplay_Facetime_USB
    DTC_FD0F_06,
    DTC_FD0F_42,
    DTC_FD10_51,           // ECNR_Carplay_NBS_Wifi
    DTC_FD10_06,
    DTC_FD10_42,
    DTC_FD11_51,           // ECNR_Carplay_WBS_Wifi
    DTC_FD11_06,
    DTC_FD11_42,
    DTC_FD12_51,           // ECNR_Carplay_Facetime_Wifi
    DTC_FD12_06,
    DTC_FD12_42,
    DTC_FD13_51,           // ECNR_CpSiriWb_Wifi
    DTC_FD13_06,
    DTC_FD13_42,
    DTC_FD14_51,           // ECNR_CpSiriWb_USB
    DTC_FD14_06,
    DTC_FD14_42,
    DTC_FD15_51,           // ECNR_3rd_Tel_Swb
    DTC_FD15_06,
    DTC_FD15_42,
    DTC_FD16_51,           // ECNR_3rd_VR
    DTC_FD16_06,
    DTC_FD16_42,
    DTC_FD17_51,           // ECNR_AaVoiceWb
    DTC_FD17_06,
    DTC_FD17_42,
    DTC_FD18_51,           // ECNR_VPA
    DTC_FD18_06,
    DTC_FD18_42,
    DTC_FD19_51,           // RemainingChargingTime_LUT_BATTERY_SIZE_1
    DTC_FD19_06,
    DTC_FD19_42,
    DTC_FD1A_51,           // RemainingChargingTime_LUT_BATTERY_SIZE_2
    DTC_FD1A_06,
    DTC_FD1A_42,
    DTC_FD1B_51,           // RemainingChargingTime_LUT_BATTERY_SIZE_3
    DTC_FD1B_06,
    DTC_FD1B_42,
    DTC_FD1C_51,           // Total_Losses_Map_LUT_BATTERY_SIZE_1
    DTC_FD1C_06,
    DTC_FD1C_42,
    DTC_FD1D_51,           // Total_Losses_Map_LUT_BATTERY_SIZE_2
    DTC_FD1D_06,
    DTC_FD1D_42,
    DTC_FD1E_51,           // Total_Losses_Map_LUT_BATTERY_SIZE_3
    DTC_FD1E_06,
    DTC_FD1E_42,
    DTC_FD1F_51,           // PowerMap_Regen_LUT_BATTERY_SIZE_1
    DTC_FD1F_06,
    DTC_FD1F_42,
    DTC_FD20_51,           // PowerMap_Regen_LUT_BATTERY_SIZE_2
    DTC_FD20_06,
    DTC_FD20_42,
    DTC_FD21_51,           // PowerMap_Regen_LUT_BATTERY_SIZE_3
    DTC_FD21_06,
    DTC_FD21_42,
    DTC_FD22_51,           // Quick_Charge_Battery_Preconditioning_Energy_LUT_BATTERY_SIZE_1
    DTC_FD22_06,
    DTC_FD22_42,
    DTC_FD23_51,           // Quick_Charge_Battery_Preconditioning_Energy_LUT_BATTERY_SIZE_2
    DTC_FD23_06,
    DTC_FD23_42,
    DTC_FD24_51,           // Quick_Charge_Battery_Preconditioning_Energy_LUT_BATTERY_SIZE_3
    DTC_FD24_06,
    DTC_FD24_42,
    DTC_FD25_51,           // Auxiliary_drain_at_temp
    DTC_FD25_06,
    DTC_FD25_42,
    DTC_FD26_51,           // Battery_Losses_LUT_BATTERY_SIZE_1
    DTC_FD26_06,
    DTC_FD26_42,
    DTC_FD27_51,           // Battery_Losses_LUT_BATTERY_SIZE_2
    DTC_FD27_06,
    DTC_FD27_42,
    DTC_FD28_51,           // Battery_Losses_LUT_BATTERY_SIZE_3
    DTC_FD28_06,
    DTC_FD28_42,
    DTC_FD29_51,           // SOC_Conversion_LUT
    DTC_FD29_06,
    DTC_FD29_42,
    DTC_FD2A_51,           // Tbatt_Conversion_LUT
    DTC_FD2A_06,
    DTC_FD2A_42,
    DTC_FD2B_51,           // Reducer_Losses_LUT
    DTC_FD2B_06,
    DTC_FD2B_42,
    DTC_FD2C_51,           // Emachine_Inverter_Losses_LUT
    DTC_FD2C_06,
    DTC_FD2C_42,
    DTC_FD2D_51,           // UDC_Conversion_LUT
    DTC_FD2D_06,
    DTC_FD2D_42,
    DTC_FD2E_51,           // Available_Energy_LUT_BATTERY_SIZE_1
    DTC_FD2E_06,
    DTC_FD2E_42,
    DTC_FD2F_51,           // Available_Energy_LUT_BATTERY_SIZE_2
    DTC_FD2F_06,
    DTC_FD2F_42,
    DTC_FD30_51,           // Available_Energy_LUT_BATTERY_SIZE_3
    DTC_FD30_06,
    DTC_FD30_42,
    DTC_FD31_51,           //ECNR_BTVOICENB_PREMIUM
    DTC_FD31_06,
    DTC_FD31_42,
    DTC_FD32_51,           //ECNR_BTVOICEWB_PREMIUM
    DTC_FD32_06,
    DTC_FD32_42,
    DTC_FD33_51,           //ECNR_CARPLAY_NBS_USB_PREMIUM
    DTC_FD33_06,
    DTC_FD33_42,
    DTC_FD34_51,           //ECNR_CARPLAY_WBS_USB_PREMIUM
    DTC_FD34_06,
    DTC_FD34_42,
    DTC_FD35_51,           //ECNR_CARPLAY_FACETIME_USB_PREMIUM
    DTC_FD35_06,
    DTC_FD35_42,
    DTC_FD36_51,           //ECNR_CARPLAY_NBS_WIFI_PREMIUM
    DTC_FD36_06,
    DTC_FD36_42,
    DTC_FD37_51,           //ECNR_CARPLAY_WBS_WIFI_PREMIUM
    DTC_FD37_06,
    DTC_FD37_42,
    DTC_FD38_51,           //ECNR_CARPLAY_FACETIME_WIFI_PREMIUM
    DTC_FD38_06,
    DTC_FD38_42,
    DTC_FD39_51,           //ECNR_CPSIRIWB_WIFI_PREMIUM
    DTC_FD39_06,
    DTC_FD39_42,
    DTC_FD3A_51,           //ECNR_CPSIRIWB_USB_PREMIUM
    DTC_FD3A_06,
    DTC_FD3A_42,
    DTC_FD3B_51,           //ECNR_3RD_TEL_SWB_PREMIUM
    DTC_FD3B_06,
    DTC_FD3B_42,
    DTC_FD3C_51,           //ECNR_3RD_VR_PREMIUM
    DTC_FD3C_06,
    DTC_FD3C_42,
    DTC_FD3D_51,           //ECNR_AAVOICEWB_PREMIUM
    DTC_FD3D_06,
    DTC_FD3D_42,
    DTC_FD3E_51,           //ECNR_VPA_PREMIUM
    DTC_FD3E_06,
    DTC_FD3E_42,
    DTC_FD3F_51,          //REMAININGCHARGINGTIME_LUT_V2_BATTERY_SIZE_1
    DTC_FD3F_06,
    DTC_FD3F_42,
    DTC_FD40_51,          //REMAININGCHARGINGTIME_LUT_V2_BATTERY_SIZE_2
    DTC_FD40_06,
    DTC_FD40_42,
    DTC_FD45_51,          //REMAININGCHARGINGTIME_LUT_V2_BATTERY_SIZE_3
    DTC_FD45_06,
    DTC_FD45_42,
    DTC_FD46_51,          //TBATT_CONVERSION_LUT_V2
    DTC_FD46_06,
    DTC_FD46_42,
    DTC_FD41_51,          //ECNR_CARPLAY_SWBS_USB_PREMIUM
    DTC_FD41_06,
    DTC_FD41_42,
    DTC_FD42_51,          //ECNR_CARPLAY_SWBS_WIFI_PREMIUM
    DTC_FD42_06,
    DTC_FD42_42,
    DTC_FD43_51,          //ECNR_CARPLAY_SWBS_USB
    DTC_FD43_06,
    DTC_FD43_42,
    DTC_FD44_51,          //ECNR_CARPLAY_SWBS_WIFI
    DTC_FD44_06,
    DTC_FD44_42,
    DTC_FD47_51,          //ECNR_CARPLAY_FBS_USB
    DTC_FD47_06,
    DTC_FD47_42,
    DTC_FD48_51,          //ECNR_CARPLAY_FBS_WIFI
    DTC_FD48_06,
    DTC_FD48_42,
    DTC_FD49_51,          //ECNR_CARPLAY_FBS_USB_PREMIUM
    DTC_FD49_06,
    DTC_FD49_42,
    DTC_FD4A_51,          //ECNR_CARPLAY_FBS_WIFI_PREMIUM
    DTC_FD4A_06,
    DTC_FD4A_42,
    DTC_FD4B_51,          //QUICK_CHARGE_BATTERY_PRECONDITIONING_ENERGY_LUT_V2_BATTERY_SIZE_1
    DTC_FD4B_06,
    DTC_FD4B_42,
    DTC_FD4C_51,          //QUICK_CHARGE_BATTERY_PRECONDITIONING_ENERGY_LUT_V2_BATTERY_SIZE_2
    DTC_FD4C_06,
    DTC_FD4C_42,
    DTC_FD4D_51,          //QUICK_CHARGE_BATTERY_PRECONDITIONING_ENERGY_LUT_V2_BATTERY_SIZE_3
    DTC_FD4D_06,
    DTC_FD4D_42,
    DTC_FD4E_51,          //TARGET_TBATT_LUT_BATTERY_SIZE_1
    DTC_FD4E_06,
    DTC_FD4E_42,
    DTC_FD4F_51,          //TARGET_TBATT_LUT_BATTERY_SIZE_2
    DTC_FD4F_06,
    DTC_FD4F_42,
    DTC_FD50_51,          //TARGET_TBATT_LUT_BATTERY_SIZE_3
    DTC_FD50_06,
    DTC_FD50_42,
    DTC_FD51_51,          //Safety_Score_Algorithm_Settings
    DTC_FD51_06,
    DTC_FD51_42,
    DTC_FD52_51,          //Safety_Score_Service_Settings
    DTC_FD52_06,
    DTC_FD52_42,
    DTC_FD53_51,          //F2_Wind_LUT
    DTC_FD53_06,
    DTC_FD53_42,
    DTC_FD54_51,          //Vehicle_Cockpit_Interior
    DTC_FD54_06,
    DTC_FD54_42,
    DTC_FD55_51,          //ECNR_AVATAR_WUW
    DTC_FD55_06,
    DTC_FD55_42,
    DTC_FD56_51,          //ECNR_AVATAR_VR
    DTC_FD56_06,
    DTC_FD56_42,
    DTC_FD57_51,          //ECNR_AVATAR_WUW_PREMIUM
    DTC_FD57_06,
    DTC_FD57_42,
    DTC_FD58_51,          //ECNR_AVATAR_VR_PREMIUM
    DTC_FD58_06,
    DTC_FD58_42,
    DTC_FD61_51,          //ECNR_CP_ESIRI_WIFI
    DTC_FD61_06,
    DTC_FD61_42,
    DTC_FD62_51,          //ECNR_CP_ESIRI_USB
    DTC_FD62_06,
    DTC_FD62_42,
    DTC_FD63_51,          //ECNR_CP_ESIRI_WIFI_ACCESS
    DTC_FD63_06,
    DTC_FD63_42,
    DTC_FD64_51,          //ECNR_CP_ESIRI_USB_ACCESS
    DTC_FD64_06,
    DTC_FD64_42,
    DTC_FD65_51,          //ECNR_AVATAR_VR_PREMIUM
    DTC_FD65_06,
    DTC_FD65_42,
    DTC_FD66_51,          //ECNR_AVATAR_VR_PREMIUM
    DTC_FD66_06,
    DTC_FD66_42,
    DTC_FD67_51,          //ARKAMYS_SOUNDSTAGING_ACCESS_CLASSIC_LHD
    DTC_FD67_06,
    DTC_FD67_42,
    DTC_FD68_51,          //ARKAMYS_SOUNDSTAGING_ACCESS_CLASSIC_RHD
    DTC_FD68_06,
    DTC_FD68_42,
    DTC_FD69_51,          //ARKAMYS_SOUNDSTAGING_ACCESS_AUDITO_LHD
    DTC_FD69_06,
    DTC_FD69_42,
    DTC_FD6A_51,          //ARKAMYS_SOUNDSTAGING_ACCESS_AUDITO_RHD
    DTC_FD6A_06,
    DTC_FD6A_42,
    DTC_FD59_51,          //AUXILIARY_DRAIN_AT_TEMP_LUT_V2
    DTC_FD59_06,
    DTC_FD59_42,
    DTC_FD5A_51,          //MEX_MODE_CORRECTION_LUT
    DTC_FD5A_06,
    DTC_FD5A_42,
    DTC_FD5B_51,          //EMACHINE_INVERTER_LOSSES_LUT_V2
    DTC_FD5B_06,
    DTC_FD5B_42,
    DTC_FD5C_51,          //REDUCER_LOSSES_LUT_V2
    DTC_FD5C_06,
    DTC_FD5C_42,
    DTC_FD5D_51,          //DT_REPARTITION_LUT
    DTC_FD5D_06,
    DTC_FD5D_42,
    DTC_FD5E_51,          //QC_BATTERY_PRECONDITIONING_TIME_LUT
    DTC_FD5E_06,
    DTC_FD5E_42,
    DTC_FD5F_51,          //QC_BATTERY_PRECONDITIONING_CORRECTION_LUT
    DTC_FD5F_06,
    DTC_FD5F_42,
    DTC_FD60_51,          //AIO_Camera_Settings
    DTC_FD60_06,
    DTC_FD60_42,
    DTC_FD6B_51,          //ECNR_BTVOICENB_ACCESS
    DTC_FD6B_06,
    DTC_FD6B_42,
    DTC_FD6C_51,          //ECNR_BTVOICEWB_ACCESS
    DTC_FD6C_06,
    DTC_FD6C_42,
    DTC_FD6D_51,          //ECNR_CARPLAY_NBS_USB_ACCESS
    DTC_FD6D_06,
    DTC_FD6D_42,
    DTC_FD6E_51,          //ECNR_CARPLAY_WBS_USB_ACCESS
    DTC_FD6E_06,
    DTC_FD6E_42,
    DTC_FD6F_51,          //ECNR_CARPLAY_FBS_USB_ACCESS
    DTC_FD6F_06,
    DTC_FD6F_42,
    DTC_FD70_51,          //ECNR_CARPLAY_SWBS_USB_ACCESS
    DTC_FD70_06,
    DTC_FD70_42,
    DTC_FD71_51,          //ECNR_CARPLAY_FACETIME_USB_ACCESS
    DTC_FD71_06,
    DTC_FD71_42,
    DTC_FD72_51,          //ECNR_CARPLAY_NBS_WIFI_ACCESS
    DTC_FD72_06,
    DTC_FD72_42,
    DTC_FD73_51,          //ECNR_CARPLAY_WBS_WIFI_ACCESS
    DTC_FD73_06,
    DTC_FD73_42,
    DTC_FD74_51,          //ECNR_CARPLAY_FBS_WIFI_ACCESS
    DTC_FD74_06,
    DTC_FD74_42,
    DTC_FD75_51,          //ECNR_CARPLAY_SWBS_WIFI_ACCESS
    DTC_FD75_06,
    DTC_FD75_42,
    DTC_FD76_51,          //ECNR_CARPLAY_FACETIME_WIFI_ACCESS
    DTC_FD76_06,
    DTC_FD76_42,
    DTC_FD77_51,          //ECNR_CPSIRIWB_WIFI_ACCESS
    DTC_FD77_06,
    DTC_FD77_42,
    DTC_FD78_51,          //ECNR_CPSIRIWB_USB_ACCESS
    DTC_FD78_06,
    DTC_FD78_42,
    DTC_FD79_51,          //ECNR_3RD_TEL_SWB_ACCESS
    DTC_FD79_06,
    DTC_FD79_42,
    DTC_FD7A_51,          //ECNR_3RD_VR_ACCESS
    DTC_FD7A_06,
    DTC_FD7A_42,
    DTC_FD7B_51,          //ECNR_AAVOICEWB_ACCESS
    DTC_FD7B_06,
    DTC_FD7B_42,
    DTC_FD7C_51,          //ECNR_VPA_ACCESS
    DTC_FD7C_06,
    DTC_FD7C_42,
    DTC_FD7D_51,          //ECNR_AVATAR_WUW_ACCESS
    DTC_FD7D_06,
    DTC_FD7D_42,
    DTC_FD7E_51,          //ECNR_AVATAR_VR_ACCESS
    DTC_FD7E_06,
    DTC_FD7E_42,
    DTC_FD7F_51,          //F2_Air_Shutter_Correction_LUT  F2_AIR_SHUTTER_CORRECTION_LUT
    DTC_FD7F_06,
    DTC_FD7F_42,
    DTC_MAX,
};

enum {
    VEHICLE_EE_ARCHITECTURE_DETECTION_FAILURE,                 // 0
    REQUEST_EE_ARCHITECTURE_READ_FAILURE,                      // 1
    UNDEFINED,                                                 // 2
    EE_ARCHI_110_AND_VEHICLE_ARCHI_200_400,                    // 3
    EE_ARCHI_200_AND_VEHICLE_ARCHI_110,                        // 4
    EE_ARCHI_400_AND_VEHICLE_ARCHI_110,                        // 5
    SUBFW_CONFIGURATION_FAILURE,                               // 6
};

typedef struct {
    uint16_t    code;
    uint8_t     fault;
    uint16_t    index;
} T_DIAGLIST;

typedef struct {
    int         index;
    uint8_t      configvalue;
} T_DIAGCONFIGLIST;

typedef struct {
    uint16_t        dtccode;
    uint8_t	        fault_type;
    uint8_t         status;
    uint8_t          fdc;
    bool            bEn;
} T_DTCDATA;

typedef struct {
    uint32_t        mileage;
    uint8_t         ocnt;
    uint8_t         svolt;          // range 0 ~ 24V, resolution 0.1V > 0x00 ~ 0xF0
    uint16_t        itemp;          // range 0 ~ 127��C, resolution 0.1��C > 0x0 ~ 0x4F6
} T_SNAPSHOT;

typedef struct {
    uint8_t         gade;
    uint8_t         svolt;
    uint16_t        itemp;
    uint32_t        mileage;
} T_DID;

typedef struct {
    uint16_t        dtcnum;
    uint32_t        mileage;
    uint8_t         ocnt;
} T_LASTSNAPSHOT;

typedef struct {
    uint16_t        part;
    uint16_t        dtccode;
    uint16_t        faulttype;
    bool            bootchked;
} T_INTERFDTC;

typedef struct {
    int              index;
    uint8_t          value_0;
    uint8_t          value_1;
    uint8_t          config_value;
} T_DTCMUXLIST;

typedef struct {
    uint16_t        dtccode;
    uint8_t         fault;
    uint8_t         pfdata[SIZE_CASSETS_PKG_FAILED];         // CUSTOM_ASSETS_PACKAGE_FAILED
    uint8_t         dfdata[SIZE_CASSETS_DEPEND_FAILED];      // CUSTOM_ASSETS_DEPENDENCY_FAILED
    uint8_t         rfdata[SIZE_CASSETS_RES_FAILED];         // CUSTOM_ASSETS_RESSOURCE_FAILED
    uint8_t         errcodedata;                             // CNF_CUSTOM_ASSETS_ERROR_CODE
} T_SNAPSHOT_REC2;

typedef struct {
    uint8_t         kswdata[SIZE_SS_RECORD_NUM_03_LABEL];          // KERNEL_SOFTWARE_WATCHDOG

    uint8_t         shnsdata[SIZE_SS_RECORD_NUM_03_LABEL];         // SOC_HW_NON_SECURE_WD
    uint8_t         sbsdata[SIZE_SS_RECORD_NUM_03_LABEL];          // SOC_BUS_HANG
    uint8_t         shsdata[SIZE_SS_RECORD_NUM_03_LABEL];          // SOC_HW_SECURE_WD
    uint8_t         usvdata[SIZE_SS_RECORD_NUM_03_LABEL];          // UC_SOC_PING_VHAL_COMMUNICATION
    uint8_t         vsgdata[SIZE_SS_RECORD_NUM_03_LABEL];          // VUC_SOC_GPIO_ON_SHUTDOWN_PHASE
    uint8_t         errhook_reset[SIZE_SS_RECORD_NUM_03_LABEL];    // ERRORHOOK_RESET
    uint8_t         watchdog_reset[SIZE_SS_RECORD_NUM_03_LABEL];   // WATCHDOG_RESET
} T_SNAPSHOT_REC3;
typedef struct {
    uint8_t         eeArchitureInfo;          // EE ARCHITECTURE INFO
} T_SNAPSHOT_REC4;

/*GADE >= 0*/
#define GADE_GROUP0 {SLEEP_OR_CRANK_FAULT,  AUTO_ACC_FAULT, DISABLE_DIAGMUXDTC_ALL_FAULT,\
                                                    ENABLE_DIAGMUXDTC_ALL_FAULT, FOTA_SWITCH_FAULT,\
                                                    GADE_LEVEL_5, GADE_LEVEL_6, UNAVAILABLE_GADE\
                                                    }

/*GADE >= 1*/
#define GADE_GROUP1 { AUTO_ACC_FAULT, DISABLE_DIAGMUXDTC_ALL_FAULT,\
                                                    ENABLE_DIAGMUXDTC_ALL_FAULT, FOTA_SWITCH_FAULT,\
                                                    GADE_LEVEL_5, GADE_LEVEL_6, UNAVAILABLE_GADE\
                                                    }

/* GADE >= 3*/
#define GADE_GROUP2 { ENABLE_DIAGMUXDTC_ALL_FAULT, FOTA_SWITCH_FAULT,\
                                                    GADE_LEVEL_5, GADE_LEVEL_6, UNAVAILABLE_GADE\
                                                    }

/* GADE == 3 or GADE == 7*/
#define GADE_GROUP3 {ENABLE_DIAGMUXDTC_ALL_FAULT, UNAVAILABLE_GADE}

/*(GADE >= 1 and GADE <= 3) or GADE == 7*/
#define GADE_GROUP4 {AUTO_ACC_FAULT, DISABLE_DIAGMUXDTC_ALL_FAULT, ENABLE_DIAGMUXDTC_ALL_FAULT, UNAVAILABLE_GADE}

/*GADE == 3*/
#define GADE_GROUP5 {ENABLE_DIAGMUXDTC_ALL_FAULT}


