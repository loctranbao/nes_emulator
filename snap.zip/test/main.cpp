#include <bits/stdc++.h>
#include "data.h"
using namespace std;

#define SIZE_CASSETS_PKG_FAILED         32 //byte
#define SIZE_CASSETS_DEPEND_FAILED      64 //byte
#define SIZE_CASSETS_RES_FAILED         80 //byte

#define SIZE_SS_RECORD_NUM_03_LABEL     62 //byte
// typedef struct {
//     uint32_t        mileage;
//     uint8_t         ocnt;
//     uint8_t         svolt;          // range 0 ~ 24V, resolution 0.1V > 0x00 ~ 0xF0
//     uint16_t        itemp;          // range 0 ~ 127��C, resolution 0.1��C > 0x0 ~ 0x4F6
// } T_SNAPSHOT;

// typedef struct {
//     uint16_t        dtccode;
//     uint8_t         fault;
//     uint8_t         pfdata[SIZE_CASSETS_PKG_FAILED];         // CUSTOM_ASSETS_PACKAGE_FAILED
//     uint8_t         dfdata[SIZE_CASSETS_DEPEND_FAILED];      // CUSTOM_ASSETS_DEPENDENCY_FAILED
//     uint8_t         rfdata[SIZE_CASSETS_RES_FAILED];         // CUSTOM_ASSETS_RESSOURCE_FAILED
//     uint8_t         errcodedata;                             // CNF_CUSTOM_ASSETS_ERROR_CODE
// } T_SNAPSHOT_REC2;

// typedef struct {
//     uint8_t         kswdata[SIZE_SS_RECORD_NUM_03_LABEL];          // KERNEL_SOFTWARE_WATCHDOG
//     uint8_t         shnsdata[SIZE_SS_RECORD_NUM_03_LABEL];         // SOC_HW_NON_SECURE_WD
//     uint8_t         sbsdata[SIZE_SS_RECORD_NUM_03_LABEL];          // SOC_BUS_HANG
//     uint8_t         shsdata[SIZE_SS_RECORD_NUM_03_LABEL];          // SOC_HW_SECURE_WD
//     uint8_t         usvdata[SIZE_SS_RECORD_NUM_03_LABEL];          // UC_SOC_PING_VHAL_COMMUNICATION
//     uint8_t         vsgdata[SIZE_SS_RECORD_NUM_03_LABEL];          // VUC_SOC_GPIO_ON_SHUTDOWN_PHASE
//     uint8_t         errhook_reset[SIZE_SS_RECORD_NUM_03_LABEL];    // ERRORHOOK_RESET
//     uint8_t         watchdog_reset[SIZE_SS_RECORD_NUM_03_LABEL];   // WATCHDOG_RESET
// } T_SNAPSHOT_REC3;

string snapShotPath = "snapshot.dat";
string snapShotRec2Path = "snapshot_2.dat";
string snapShotRec3Path = "snapshot_3.dat";
string snapShotRec4Path = "snapshot_4.dat";
string dataPath = "dtcdata.dat";
string caldataPath = "caldtcdata.dat";




#define NUM_OF_DTC_CONFIG               25
#define NUM_OF_SELFDIAG                 18
#define NUM_OF_ASSETS_DTC               3
#define NUM_OF_HU_INTER_FAILURE_2       1
#define NUM_OF_EEARCHITECTURE_DTC       1
#define NUM_OF_DTC                      DTC_FD00_51 //153
#define NUM_OF_START_CAL_DTC            DTC_FD00_51
#define CONVERT_TO_CAL_INDEX(idx)       (NUM_OF_START_CAL_DTC+(idx*3))
#define NUM_OF_DTC_MUX                  45
#define SIZE_OF_DTC_CALIBRATION         120
#define NUM_OF_INTERFDTC                16

#define SIZE_CASSETS_PKG_FAILED         32 //byte
#define SIZE_CASSETS_DEPEND_FAILED      64 //byte
#define SIZE_CASSETS_RES_FAILED         80 //byte

T_SNAPSHOT SnapshotDTC[NUM_OF_DTC];
T_SNAPSHOT_REC2 SnapshotRec2DTC[NUM_OF_ASSETS_DTC];
T_SNAPSHOT_REC3 SnapshotRec3DTC[NUM_OF_HU_INTER_FAILURE_2];
T_SNAPSHOT_REC4 SnapshotRec4DTC[NUM_OF_EEARCHITECTURE_DTC];
T_DTCDATA DataDTC[DTC_MAX] = {
    DataDTC[DTC_D000_88] = {DTC_MULTI_CAN_EXT_COMMUNICATION, FT_BUS_OFF, STATUS_INITIAL_VALUE, 0, true},     // Mutiple CANcommunication abnormality
    DataDTC[DTC_D300_88] = {DTC_MULTI_CAN_M_COMMUNICATION, FT_BUS_OFF, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9341_16] = {DTC_HU_INTER_SELF_DIAGNOSIS, FT_LOW_VOLTAGE_ERROR, STATUS_INITIAL_VALUE, 0, true},     // H/UInternal self - diagnosis abnormality
    DataDTC[DTC_9341_17] = {DTC_HU_INTER_SELF_DIAGNOSIS, FT_HIGH_VOLTAGE_ERROR, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9341_98] = {DTC_HU_INTER_SELF_DIAGNOSIS, FT_HIGH_TEMPERATURE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930E_11] = {DTC_SOUND_BUBBLE_R, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Sound bubble::Right driver loudspeaker output
    DataDTC[DTC_930E_12] = {DTC_SOUND_BUBBLE_R, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930E_13] = {DTC_SOUND_BUBBLE_R, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930E_1C] = {DTC_SOUND_BUBBLE_R, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9310_11] = {DTC_SOUND_BUBBLE_L, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Sound bubble::Left driver loudspeaker output
    DataDTC[DTC_9310_12] = {DTC_SOUND_BUBBLE_L, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9310_13] = {DTC_SOUND_BUBBLE_L, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9310_1C] = {DTC_SOUND_BUBBLE_L, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9344_11] = {DTC_LOUDSPK_R_SUBWOOFER, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker::right subwoofer output
    DataDTC[DTC_9344_12] = {DTC_LOUDSPK_R_SUBWOOFER, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9344_13] = {DTC_LOUDSPK_R_SUBWOOFER, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9344_1C] = {DTC_LOUDSPK_R_SUBWOOFER, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9345_11] = {DTC_LOUDSPK_L_SUBWOOFER, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker::left subwoofer output
    DataDTC[DTC_9345_12] = {DTC_LOUDSPK_L_SUBWOOFER, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9345_13] = {DTC_LOUDSPK_L_SUBWOOFER, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9345_1C] = {DTC_LOUDSPK_L_SUBWOOFER, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930D_11] = {DTC_LOUDSPK_FR, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker output::FRONT RIGHT
    DataDTC[DTC_930D_12] = {DTC_LOUDSPK_FR, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930D_13] = {DTC_LOUDSPK_FR, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930D_1C] = {DTC_LOUDSPK_FR, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9311_11] = {DTC_LOUDSPK_RL, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker output::REAR LEFT
    DataDTC[DTC_9311_12] = {DTC_LOUDSPK_RL, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9311_13] = {DTC_LOUDSPK_RL, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9311_1C] = {DTC_LOUDSPK_RL, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930F_11] = {DTC_LOUDSPK_FL, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker output::FRONT LEFT
    DataDTC[DTC_930F_12] = {DTC_LOUDSPK_FL, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930F_13] = {DTC_LOUDSPK_FL, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930F_1C] = {DTC_LOUDSPK_FL, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930B_11] = {DTC_LOUDSPK_RR, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker output::REAR RIGHT
    DataDTC[DTC_930B_12] = {DTC_LOUDSPK_RR, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930B_13] = {DTC_LOUDSPK_RR, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930B_1C] = {DTC_LOUDSPK_RR, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930A_11] = {DTC_LOUDSPK_R_SURROUND, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker output::RIGHT SURROUND
    DataDTC[DTC_930A_12] = {DTC_LOUDSPK_R_SURROUND, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930A_13] = {DTC_LOUDSPK_R_SURROUND, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930A_1C] = {DTC_LOUDSPK_R_SURROUND, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930C_11] = {DTC_LOUDSPK_L_SURROUND, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker output::LEFT SURROUND
    DataDTC[DTC_930C_12] = {DTC_LOUDSPK_L_SURROUND, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930C_13] = {DTC_LOUDSPK_L_SURROUND, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_930C_1C] = {DTC_LOUDSPK_L_SURROUND, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9348_11] = {DTC_LOUDSPK_CENTERFILL, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Loudspeaker output::Centerfill
    DataDTC[DTC_9348_12] = {DTC_LOUDSPK_CENTERFILL, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9348_13] = {DTC_LOUDSPK_CENTERFILL, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9348_1C] = {DTC_LOUDSPK_CENTERFILL, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9320_13] = {DTC_LOUDSPK_RR_TWEETER, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::REAR RIGHT
    DataDTC[DTC_9323_13] = {DTC_LOUDSPK_RL_TWEETER, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::REAR LEFT
    DataDTC[DTC_9321_11] = {DTC_LOUDSPK_FR_TWEETER, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::FRONT RIGHT
    DataDTC[DTC_9321_12] = {DTC_LOUDSPK_FR_TWEETER, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9321_13] = {DTC_LOUDSPK_FR_TWEETER, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9321_1C] = {DTC_LOUDSPK_FR_TWEETER, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9322_11] = {DTC_LOUDSPK_FL_TWEETER, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::FRONT LEFT
    DataDTC[DTC_9322_12] = {DTC_LOUDSPK_FL_TWEETER, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9322_13] = {DTC_LOUDSPK_FL_TWEETER, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9322_1C] = {DTC_LOUDSPK_FL_TWEETER, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9315_11] = {DTC_ANTENNA_AM_FM1, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // AM/FM1 antenna supply
    DataDTC[DTC_9315_13] = {DTC_ANTENNA_AM_FM1, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9316_11] = {DTC_ANTENNA_FM2, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // FM2 antenna supply
    DataDTC[DTC_9316_13] = {DTC_ANTENNA_FM2, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9346_11] = {DTC_ANTENNA_GNSS, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // GNSS antenna
    DataDTC[DTC_9346_13] = {DTC_ANTENNA_GNSS, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9303_11] = {DTC_ANTENNA_DAB, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // DAB antenna connection
    DataDTC[DTC_9303_13] = {DTC_ANTENNA_DAB, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9327_11] = {DTC_MICROPHONE, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Microphone Alliance supply line
    DataDTC[DTC_9327_12] = {DTC_MICROPHONE, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9327_13] = {DTC_MICROPHONE, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9375_11] = {DTC_ANALOG_DIGIT_RVC_SUPPLY, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Rearview Camera Power supply
    DataDTC[DTC_9375_12] = {DTC_ANALOG_DIGIT_RVC_SUPPLY, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9375_13] = {DTC_ANALOG_DIGIT_RVC_SUPPLY, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9351_49] = {DTC_HU_INTER_ECU_DCLASS_AMP_N1, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU D-class Amplifier n1
    DataDTC[DTC_935E_49] = {DTC_HU_INTER_ECU_FAN, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU FAN
    DataDTC[DTC_931F_49] = {DTC_HU_INTER_ECU_DSP, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU DSP
    DataDTC[DTC_9325_49] = {DTC_HU_INTER_ECU_A2B, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU A2B tranceiver
    DataDTC[DTC_9326_49] = {DTC_HU_INTER_ECU_DCLASS_AMP_N2, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU D-class Amplifier n2
    DataDTC[DTC_9335_8F] = {DTC_A2B, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // A2B connection
    DataDTC[DTC_E150_87] = {DTC_ACU_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // ACU_A101
    DataDTC[DTC_E152_87] = {DTC_ADAS_A116, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // ADAS_A116
    DataDTC[DTC_E141_87] = {DTC_ATCU_A109, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // ATCU_A109
    DataDTC[DTC_E025_87] = {DTC_AUDIOAMP_A1, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // AUDIOamp_A1
    DataDTC[DTC_E175_87] = {DTC_AVM_A102, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // AVM_A102
    DataDTC[DTC_E14F_87] = {DTC_BCM_A107, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // BCM_A107
    DataDTC[DTC_E176_87] = {DTC_CDM_A116, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // CDM_A116
    DataDTC[DTC_E18C_87] = {DTC_CGW_A2, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // CGW_A2
    DataDTC[DTC_E15B_87] = {DTC_USM_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // USM_A101
    DataDTC[DTC_E19D_87] = {DTC_DMC_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // DMC_A101
    DataDTC[DTC_E193_87] = {DTC_DSMU_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // DSMU_A101
    DataDTC[DTC_E140_87] = {DTC_ECM_A108, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // ECM_A108
    DataDTC[DTC_E159_87] = {DTC_EPS_A103, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // EPS_A103
    DataDTC[DTC_E16B_87] = {DTC_FRCAMERA_A110, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // FRCAMERA_A110
    DataDTC[DTC_E104_87] = {DTC_FWS_R3, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // FWS_R3
    DataDTC[DTC_E143_87] = {DTC_HEVC_A104, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // HEVC_A104
    DataDTC[DTC_E118_87] = {DTC_HFM_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // HFM_A101
    DataDTC[DTC_E173_87] = {DTC_HUD_A1, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // HUD_A1
    DataDTC[DTC_E1A0_87] = {DTC_HVAC_A2, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // HVAC_A2
    DataDTC[DTC_E14E_87] = {DTC_METER_A103, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // METER_A103
    DataDTC[DTC_E194_87] = {DTC_PSCU_A102, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // PSCU_A102
    DataDTC[DTC_E165_87] = {DTC_SONAR_A4, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // SONAR_A4
    DataDTC[DTC_E16E_87] = {DTC_SRRR_A106, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // SRRR_A106
    DataDTC[DTC_E187_87] = {DTC_SR_CANHS_R_02, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // SR_CANHS_R_02
    DataDTC[DTC_E117_87] = {DTC_TCU_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // TCU_A101
    DataDTC[DTC_E148_87] = {DTC_VDC_A114, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // VDC_A114
    DataDTC[DTC_E113_87] = {DTC_VSP_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // VSP_A101
    DataDTC[DTC_E18D_87] = {DTC_WCBS_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // WCBS_A101
    DataDTC[DTC_E156_87] = {DTC_STRG_A1, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // STRG_A1
    DataDTC[DTC_E073_87] = {DTC_CENTRALPANEL_R101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // CentralPanel_R101
    DataDTC[DTC_9341_49] = {DTC_HU_INTER_SELF_DIAGNOSIS, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // H/UInternal self - diagnosis abnormality
    DataDTC[DTC_9341_55] = {DTC_HU_INTER_SELF_DIAGNOSIS, FT_NOT_CONFIGURED, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_93EC_55] = {DTC_INTERNAL_SELF_DIAG, FT_NOT_CONFIGURED, STATUS_INITIAL_VALUE, 0, true},     // Internal self-diagnosis abnormality
    DataDTC[DTC_93EC_52] = {DTC_INTERNAL_SELF_DIAG, FT_NOT_ACTIVATED, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9314_11] = {DTC_ANTENNA_WIFI_EXT, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Wifi ext antenna connection
    DataDTC[DTC_9314_13] = {DTC_ANTENNA_WIFI_EXT, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_932A_13] = {DTC_USB_MCH1, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},     // MCH1 Ext.USB
    DataDTC[DTC_93D9_8F] = {DTC_USB_MCH1_ERRATIC, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_932C_13] = {DTC_USB_TCU, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},     // TCU Ext.USB
    DataDTC[DTC_93E5_8F] = {DTC_USB_TCU_ERRATIC, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_931A_8F] = {DTC_CENTRAL_GATEWAY_ETHERNET, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // Central Gateway ethernet
    DataDTC[DTC_931B_8F] = {DTC_AIO_CAMERA_ETHERNET, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // AIO camera ethernet
    DataDTC[DTC_931C_8F] = {DTC_TCU_ETHERNET, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // TCU ethernet
    DataDTC[DTC_9339_8F] = {DTC_ANALOG_RVC_VIDEO, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // CVBS IN rear cam line
    DataDTC[DTC_93DA_8F] = {DTC_DIGIT_RVC_AVM_VIDEO, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, false},     // LVDS In LVDS Camera
    DataDTC[DTC_93DD_8F] = {DTC_CENTRAL_PANEL, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, false},     // LVDS IN CP Line
    DataDTC[DTC_93DD_87] = {DTC_CENTRAL_PANEL, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, false},
    DataDTC[DTC_93DB_8F] = {DTC_LVDS_2ND_DISPLAY, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // LVDS IN 2nd Display
    DataDTC[DTC_93DB_87] = {DTC_LVDS_2ND_DISPLAY, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_93D8_8F] = {DTC_LVDS_DTV_BOX, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // LVDS IN DTV Box
    DataDTC[DTC_93DF_8F] = {DTC_LVDS_OUT_RSE, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // LVDS OUT RSE
    DataDTC[DTC_931D_8F] = {DTC_AR_NAV_CAMERA, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // AR NAV camera
    DataDTC[DTC_9342_62] = {DTC_HU_INTER_ECU_LOCKED, FT_SIGNAL_COMPARE_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // Anthift(Locked ECU)
    DataDTC[DTC_93CF_73] = {DTC_HU_INTER_ECU_BUTTONS, FT_ACTUATOR_STUCK_CLOSED, STATUS_INITIAL_VALUE, 0, true},     // ECU Buttons
    DataDTC[DTC_9347_49] = {DTC_HU_INTER_ECU_BT_WIFI, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU Bluetooth
    DataDTC[DTC_931E_49] = {DTC_HU_INTER_ECU_GNSS, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU GNSS
    DataDTC[DTC_9324_49] = {DTC_HU_INTER_ECU_CPU, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU CPU
    DataDTC[DTC_932B_49] = {DTC_HU_INTER_ECU_LPDDR4, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU LPDDR4
    DataDTC[DTC_932D_49] = {DTC_HU_INTER_ECU_EMMC_UFS, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU eMMC/UFS
    DataDTC[DTC_932E_49] = {DTC_HU_INTER_ECU_PMIC, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU PMIC
    DataDTC[DTC_932F_49] = {DTC_HU_INTER_ECU_ETHERNET_SWITCH, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU Ethernet switch
    DataDTC[DTC_9330_49] = {DTC_HU_INTER_ECU_CP_SERIAL, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU CP serializer
    DataDTC[DTC_9331_49] = {DTC_HU_INTER_ECU_AVM_RVC_DESERIAL, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU AVM/RVC deserializer
    DataDTC[DTC_9332_49] = {DTC_HU_INTER_ECU_RVC_CVBS, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // ECU RVC CVBS
    DataDTC[DTC_93E1_06] = {DTC_PART_AUTHENTICATION, FT_ALGORYTHM_BASED_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // Part Enrollment Error
    DataDTC[DTC_AE22_06] = {DTC_FOTA, FT_ALGORYTHM_BASED_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // FOTA _Inconsistency_state
    DataDTC[DTC_9337_11] = {DTC_AR_CAMERA, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, false},
    DataDTC[DTC_9337_12] = {DTC_AR_CAMERA, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, false},
    DataDTC[DTC_9337_13] = {DTC_AR_CAMERA, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, false},
    DataDTC[DTC_9352_47] = {DTC_HU_INTER_FAILURE_2, FT_WATCHDOG_SAFETY_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // Unexpected reboot due to watchdog
    DataDTC[DTC_9357_29] = {DTC_C_ASSETS_REFERENCE_NF, FT_INVALID_SIGNAL, STATUS_INITIAL_VALUE, 0, true},     // Car visual CUSTOM_ASSETS_REFERENCE not found
    DataDTC[DTC_9358_29] = {DTC_C_ASSETS_DEFENDENCY_INST_NF, FT_INVALID_SIGNAL, STATUS_INITIAL_VALUE, 0, true},     // Car visual CUSTOM_ASSETS_INSTALLED not found
    DataDTC[DTC_9359_06] = {DTC_ASSETSD_RUNTIME_ERROR, FT_ALGORYTHM_BASED_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // Car visual ASSETD Runtime error
    DataDTC[DTC_93E0_47] = {DTC_SAFE_MODE, FT_WATCHDOG_SAFETY_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // Safe Mode    // Calibration Logical block
    DataDTC[DTC_EA13_88] = {DTC_IVI_CAN_COMMUNICATION, FT_BUS_OFF, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_EA10_88] = {DTC_M1_CAN_COMMUNICATION, FT_BUS_OFF, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9320_11] = {DTC_LOUDSPK_RR_TWEETER, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::REAR RIGHT
    DataDTC[DTC_9320_12] = {DTC_LOUDSPK_RR_TWEETER, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::REAR RIGHT
    DataDTC[DTC_9320_1C] = {DTC_LOUDSPK_RR_TWEETER, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::REAR RIGHT
    DataDTC[DTC_9323_11] = {DTC_LOUDSPK_RL_TWEETER, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::REAR LEFT
    DataDTC[DTC_9323_12] = {DTC_LOUDSPK_RL_TWEETER, FT_SHORT_TO_BATTERY, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::REAR LEFT
    DataDTC[DTC_9323_1C] = {DTC_LOUDSPK_RL_TWEETER, FT_CIRCUIT_VOLTAGE_OUT_OF_RANGE, STATUS_INITIAL_VALUE, 0, true},     // Tweeter output::REAR LEFT
    DataDTC[DTC_9317_11] = {DTC_ANTENNA_SXM, FT_SHORT_TO_GROUND, STATUS_INITIAL_VALUE, 0, true},           // SXM antenna supply
    DataDTC[DTC_9317_13] = {DTC_ANTENNA_SXM, FT_OPEN_LOAD, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_E181_87] = {DTC_CPLC_R101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // CPLC_R101
    DataDTC[DTC_E169_87] = {DTC_PBD_A102, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},      // PBD_A102
    DataDTC[DTC_E14A_87] = {DTC_FWD_A103, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},      // FWD_A103
    DataDTC[DTC_E167_87] = {DTC_PSD_A102, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},      // PSD_A102
    DataDTC[DTC_E162_87] = {DTC_PSDL_A102, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // PSDL_A102
    DataDTC[DTC_E1B6_87] = {DTC_RSCU2R_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},   // RSCU2R_A101
    DataDTC[DTC_E1BB_87] = {DTC_RSCU3R_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},   // RSCU3R_A101
    DataDTC[DTC_E195_87] = {DTC_SCCM_A102, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},     // SCCM_A102
    DataDTC[DTC_E1A3_87] = {DTC_BLM_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},      // BLM_A101
    DataDTC[DTC_E18E_87] = {DTC_AAM_R101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},      // AAM_R101
    DataDTC[DTC_E1BE_87] = {DTC_AIRSUSP_N101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},  // AirSUSP_N101
    DataDTC[DTC_E2B8_87] = {DTC_FCP_N101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},      // FCP_N101
    DataDTC[DTC_E2B9_87] = {DTC_RCP_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},      // RCP_A101
    DataDTC[DTC_E119_87] = {DTC_EPS_A101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},      // EPS_A101
    DataDTC[DTC_E24E_87] = {DTC_METER_R101, FT_MISSING_MESSAGE, STATUS_INITIAL_VALUE, 0, true},    // METER_R101
    DataDTC[DTC_9300_29] = {DTC_BAD_DISPLAY_SIGNAL, FT_INVALID_SIGNAL, STATUS_INITIAL_VALUE, 0, true},     // Bad Display Signal
    DataDTC[DTC_931B_49] = {DTC_AIO_CAMERA_ETHERNET, FT_INTERNAL_ELECTRONIC_FAILURE, STATUS_INITIAL_VALUE, 0, true},
    DataDTC[DTC_9312_8F] = {DTC_LVDS_IN_DVR_LINE, FT_COMMUNICATION_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // LVDS in DVR Line
    DataDTC[DTC_9306_56] = {DTC_EE_ARCHI_CONFIG, FT_INCOMPATIBLE_CONFIGURATION, STATUS_INITIAL_VALUE, 0, true},     // EE Architecture incompatible
    DataDTC[DTC_9307_07] = {DTC_EHORIZON_LICENCE_ENROLLMENT, FT_ALGORITHM_FAILURE, STATUS_INITIAL_VALUE, 0, true},     // Ehorizon
};



void LoadDTCSnapShot() {
    int i;
    FILE* fd;

    if (true) {
        printf("snapShotRec2Path File exist!!\n");
        fd = fopen(snapShotRec2Path.c_str(), "rb");
        if (fd != NULL) {
            for (i = 0; i < NUM_OF_ASSETS_DTC; i++) {
                int retlen = fread((void*)& SnapshotRec2DTC[i], sizeof(T_SNAPSHOT_REC2), 1, fd);
// typedef struct {
//     uint16_t        dtccode;
//     uint8_t         fault;
//     uint8_t         pfdata[SIZE_CASSETS_PKG_FAILED];         // CUSTOM_ASSETS_PACKAGE_FAILED
//     uint8_t         dfdata[SIZE_CASSETS_DEPEND_FAILED];      // CUSTOM_ASSETS_DEPENDENCY_FAILED
//     uint8_t         rfdata[SIZE_CASSETS_RES_FAILED];         // CUSTOM_ASSETS_RESSOURCE_FAILED
//     uint8_t         errcodedata;                             // CNF_CUSTOM_ASSETS_ERROR_CODE
// } T_SNAPSHOT_REC2;
                if (retlen == 0) {
                    printf("snapShot Recordnumber 2 file read. size is zero\n");
                } else {
                    printf("SnapshotRec2DTC[%d].dtccode : %d\n", i, SnapshotRec2DTC[i].dtccode);
                    printf("SnapshotRec2DTC[%d].fault : %d\n", i, SnapshotRec2DTC[i].fault);
                    printf("SnapshotRec2DTC[%d].pfdata : %s\n", i, SnapshotRec2DTC[i].pfdata);
                    printf("SnapshotRec2DTC[%d].dfdata : %s\n", i, SnapshotRec2DTC[i].dfdata);
                    printf("SnapshotRec2DTC[%d].rfdata : %s\n", i, SnapshotRec2DTC[i].rfdata);
                    printf("SnapshotRec2DTC[%d].errcodedata : %d\n", i, SnapshotRec2DTC[i].errcodedata);
                    // for(int j = 0; i < SIZE_CASSETS_PKG_FAILED; ++j) {
                    //     printf("%c", SnapshotRec2DTC[i].pfdata[j]);
                    // }
                    // printf("\n");
                    // for(int j = 0; i < SIZE_CASSETS_DEPEND_FAILED; ++j) {
                    //     printf("%c", SnapshotRec2DTC[i].dfdata[j]);
                    // }
                    // printf("\n");
                    // for(int j = 0; i < SIZE_CASSETS_RES_FAILED; ++j) {
                    //     printf("%c", SnapshotRec2DTC[i].rfdata[j]);
                    // }
                    // printf("\n");
                }
            }
            fclose(fd);
        } else {
            printf("snapShot Recordnumber 2 file open error\n");
        }
    }

    memset(SnapshotRec3DTC, 0, sizeof(T_SNAPSHOT_REC3)*NUM_OF_HU_INTER_FAILURE_2);
    if(true) {
        printf("snapShotRec3Path File exist!!\n");
        fd = fopen(snapShotRec3Path.c_str(), "rb");
        if(fd != NULL){
            for (i = 0; i < NUM_OF_HU_INTER_FAILURE_2; i++) {
                int retlen = fread((void*)& SnapshotRec3DTC[i], sizeof(T_SNAPSHOT_REC3), 1, fd);
                if (retlen == 0) {
                    printf("snapShot Recordnumber 3 file read. size is zero\n");
                }
            }
            fclose(fd);
        } else {
            printf("snapShot Recordnumber 3 file open error\n");
        }
    }

    if (true) {
        printf("snapShotRec4Path File exist!!\n");
        fd = fopen(snapShotRec4Path.c_str(), "rb");
        if (fd != NULL) {
            for (i = 0; i < NUM_OF_EEARCHITECTURE_DTC; i++) {
                int retlen = fread((void*) &SnapshotRec4DTC[i],
                        sizeof(T_SNAPSHOT_REC4), 1, fd);
                if (retlen == 0) {
                    printf("snapShot Recordnumber 4 file read. size is zero\n");
                }
            }
            fclose(fd);
        } else {
            printf("snapShot Recordnumber 4 file open error\n");
        }
    }

}

void LoadDTC(const T_DTCDATA& dtcData, const T_SNAPSHOT& snapshot)
{
    for(auto i = 0; i < NUM_OF_DTC; ++i)
    {
        if(DataDTC[i].dtccode == dtcData.dtccode && DataDTC[i].fault_type == dtcData.fault_type)
        {
            DataDTC[i].status       = dtcData.status;
            DataDTC[i].fdc          = dtcData.fdc;
            DataDTC[i].bEn          = dtcData.bEn;

            SnapshotDTC[i].mileage  = snapshot.mileage;
            SnapshotDTC[i].ocnt     = snapshot.ocnt;
            SnapshotDTC[i].svolt    = snapshot.svolt;
            SnapshotDTC[i].itemp    = snapshot.itemp;

            printf("%s index : %d,  dtccode : 0x%x, fault_type: 0x%x, status : 0x%x, bEn : %s, mileage : %d, ocnt : %d, svolt : %d, itemp : %d\n",
             __func__, int(i),  dtcData.dtccode, dtcData.fault_type, dtcData.status, dtcData.bEn ? "true" : "false", int(snapshot.mileage),
              int(snapshot.ocnt), int(snapshot.svolt), int(snapshot.itemp));
            return;
        }
    }
    printf("%s dtccode : 0x%x, fault_type: 0x%x failure, DTC not found\n", __func__, dtcData.dtccode, dtcData.fault_type);
}

void LoadDTCData() {


    FILE* dtcFD = fopen(dataPath.c_str(), "rb");
    FILE* snapshotFD = fopen(snapShotPath.c_str(), "rb");
    if (dtcFD && snapshotFD)
    {
        size_t numDTCDataRead = DTC_DATA_READ_COUNT;
        while(numDTCDataRead == DTC_DATA_READ_COUNT)
        {
            T_DTCDATA dtcData;
            memset(&dtcData, 0, sizeof(T_DTCDATA));
            numDTCDataRead = fread((void*)& dtcData, sizeof(T_DTCDATA), DTC_DATA_READ_COUNT, dtcFD);
            if (numDTCDataRead == 0)
            {
                printf("read dtc size is zero\n");
            }

            T_SNAPSHOT snapshot;
            memset(&snapshot, 0, sizeof(T_SNAPSHOT));
            numDTCDataRead = fread((void*)& snapshot, sizeof(T_SNAPSHOT), DTC_DATA_READ_COUNT, snapshotFD);
            if(numDTCDataRead == 0)
            {
                printf("read snapshot size is zero\n");
            }

            LoadDTC(dtcData, snapshot);
        }
    } else
    {
        printf("errow while open dtcdata or snapshot\n");
    }

    if(dtcFD)
    {
        fclose(dtcFD);
    }
    if(snapshotFD)
    {
        fclose(snapshotFD);
    }
}

int main()
{
    LoadDTCData();
    LoadDTCSnapShot();
    return 0;
}